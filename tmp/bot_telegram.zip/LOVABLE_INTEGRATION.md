# 🚀 INTEGRAZIONE CON FINANZACREATIVA.LIVE (LOVABLE)

Guida completa per integrare Wheel Strategy Algorithm nella tua applicazione Lovable.

## 📋 Panoramica Architettura

```
┌─────────────────────────────────────────────────────────┐
│  finanzacreativa.live (Lovable - Frontend)              │
│  ┌───────────────────────────────────────────────────┐  │
│  │  React Components                                 │  │
│  │  • WheelStrategyDashboard                        │  │
│  │  • WheelStrategyWidget                           │  │
│  │  • Custom Hooks (useWheelStrategy)               │  │
│  └───────────────────────────────────────────────────┘  │
│                         │                                │
│                         │ REST API / WebSocket           │
│                         ▼                                │
└─────────────────────────────────────────────────────────┘
                          │
┌─────────────────────────────────────────────────────────┐
│  Backend API Server (Flask)                             │
│  ┌───────────────────────────────────────────────────┐  │
│  │  Endpoints:                                       │  │
│  │  • GET  /api/analysis                            │  │
│  │  • GET  /api/strikes                             │  │
│  │  • GET  /api/current-price                       │  │
│  │  • GET  /api/technical-indicators                │  │
│  │  • GET  /api/sentiment                           │  │
│  │  • POST /api/config                              │  │
│  └───────────────────────────────────────────────────┘  │
│                         │                                │
│                         │ API Calls                      │
│                         ▼                                │
└─────────────────────────────────────────────────────────┘
                          │
┌─────────────────────────────────────────────────────────┐
│  External APIs                                          │
│  • Binance (Market Data)                               │
│  • Alternative.me (Fear & Greed)                       │
│  • Telegram (Notifications)                            │
└─────────────────────────────────────────────────────────┘
```

---

## 🔧 STEP 1: Setup Backend API

### Opzione A: Deploy su Railway/Render (Raccomandato)

#### 1.1 Prepara i file per il deploy

Crea `Procfile`:
```
web: python api_server.py
```

Crea `runtime.txt`:
```
python-3.11.0
```

Aggiorna `requirements.txt` con dipendenze Flask:
```
requests==2.31.0
pandas==2.1.4
numpy==1.26.2
scipy==1.11.4
TA-Lib==0.4.28
python-telegram-bot==20.7
flask==3.0.0
flask-cors==4.0.0
flask-socketio==5.3.5
python-socketio==5.10.0
gunicorn==21.2.0
```

#### 1.2 Deploy su Railway

```bash
# Installa Railway CLI
npm install -g railway

# Login
railway login

# Inizializza progetto
railway init

# Deploy
railway up

# Ottieni URL
railway domain
```

#### 1.3 Deploy su Render

1. Vai su https://render.com
2. New → Web Service
3. Connetti GitHub repo
4. Configura:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn api_server:app --bind 0.0.0.0:$PORT`
5. Aggiungi variabili ambiente (vedi Step 2)
6. Deploy!

### Opzione B: Deploy su VPS Personale

```bash
# SSH nel VPS
ssh user@your-server.com

# Clona repo
git clone <your-repo>
cd wheel-strategy-bot

# Setup ambiente
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Installa TA-Lib
sudo apt-get install ta-lib
pip install TA-Lib

# Crea service systemd
sudo nano /etc/systemd/system/wheel-api.service
```

File `wheel-api.service`:
```ini
[Unit]
Description=Wheel Strategy API
After=network.target

[Service]
User=www-data
WorkingDirectory=/var/www/wheel-strategy-bot
Environment="PATH=/var/www/wheel-strategy-bot/venv/bin"
ExecStart=/var/www/wheel-strategy-bot/venv/bin/gunicorn -w 4 -b 0.0.0.0:5000 api_server:app

[Install]
WantedBy=multi-user.target
```

```bash
# Abilita e avvia
sudo systemctl enable wheel-api
sudo systemctl start wheel-api

# Setup Nginx reverse proxy
sudo nano /etc/nginx/sites-available/wheel-api
```

File Nginx:
```nginx
server {
    listen 80;
    server_name api.finanzacreativa.live;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Attiva configurazione
sudo ln -s /etc/nginx/sites-available/wheel-api /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Setup SSL con Let's Encrypt
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d api.finanzacreativa.live
```

---

## 🔐 STEP 2: Configurazione Variabili Ambiente

### Su Railway/Render Dashboard:

```
# Binance (opzionali)
BINANCE_API_KEY=your_key
BINANCE_API_SECRET=your_secret

# Telegram (per notifiche backend)
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id

# Flask
FLASK_ENV=production
SECRET_KEY=your-secret-key-here

# CORS (importante!)
ALLOWED_ORIGINS=https://finanzacreativa.live,https://www.finanzacreativa.live
```

### File `.env` locale (per sviluppo):

```bash
BINANCE_API_KEY=your_key
BINANCE_API_SECRET=your_secret
TELEGRAM_BOT_TOKEN=your_token
TELEGRAM_CHAT_ID=your_id
FLASK_ENV=development
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173
```

---

## ⚛️ STEP 3: Integrazione Frontend su Lovable

### 3.1 Setup Variabili Ambiente in Lovable

Nel tuo progetto Lovable, crea/modifica `.env`:

```bash
NEXT_PUBLIC_API_URL=https://your-api.railway.app
# oppure
NEXT_PUBLIC_API_URL=https://api.finanzacreativa.live
```

### 3.2 Installa Dipendenze (se necessario)

Lovable dovrebbe già avere questi pacchetti, ma verifica:

```bash
npm install lucide-react
# Shadcn/ui components sono già inclusi in Lovable
```

### 3.3 Copia i Componenti

**A. Copia i file React nel tuo progetto Lovable:**

```
src/
├── components/
│   └── wheel-strategy/
│       ├── WheelStrategyDashboard.tsx
│       ├── WheelStrategyWidget.tsx
│       └── index.ts
├── hooks/
│   └── useWheelStrategy.ts
└── pages/
    └── wheel-strategy.tsx  (nuova pagina)
```

**B. Crea file di export** `src/components/wheel-strategy/index.ts`:

```typescript
export { default as WheelStrategyDashboard } from './WheelStrategyDashboard';
export { default as WheelStrategyWidget } from './WheelStrategyWidget';
```

### 3.4 Crea Nuova Pagina in Lovable

Crea `src/pages/wheel-strategy.tsx`:

```typescript
import { WheelStrategyDashboard } from '@/components/wheel-strategy';

export default function WheelStrategyPage() {
  return <WheelStrategyDashboard />;
}
```

### 3.5 Aggiungi al Menu/Navigazione

Nel tuo layout o navbar, aggiungi link:

```typescript
import { Link } from 'react-router-dom';

// Nel menu
<Link to="/wheel-strategy">
  🎯 Wheel Strategy
</Link>
```

---

## 🎨 STEP 4: Personalizzazione per finanzacreativa.live

### 4.1 Adatta lo Stile al Tuo Tema

Se usi un tema custom, aggiorna i colori in `WheelStrategyDashboard.tsx`:

```typescript
// Cambia questi valori per matchare il tuo brand
const scoreColor = bestStrike.final_score >= 75 
  ? 'bg-[#your-green] text-white'  // Usa i tuoi colori
  : 'bg-[#your-yellow] text-white';
```

### 4.2 Aggiungi il Widget alla Dashboard Principale

Nel tuo `dashboard.tsx`:

```typescript
import { WheelStrategyWidget } from '@/components/wheel-strategy';

export default function Dashboard() {
  return (
    <div className="grid grid-cols-3 gap-4">
      {/* Altri widgets */}
      
      {/* Wheel Strategy Widget */}
      <WheelStrategyWidget compact={true} />
    </div>
  );
}
```

### 4.3 Integra con il Tuo Sistema di Autenticazione

Proteggi le pagine se necessario:

```typescript
import { useAuth } from '@/hooks/useAuth';

export default function WheelStrategyPage() {
  const { user, loading } = useAuth();

  if (loading) return <LoadingSpinner />;
  if (!user) return <Redirect to="/login" />;

  return <WheelStrategyDashboard />;
}
```

---

## 📱 STEP 5: Features Avanzate

### 5.1 Notifiche Push Browser

Aggiungi notifiche quando viene trovato un buon segnale:

```typescript
// In WheelStrategyDashboard.tsx
useEffect(() => {
  if (analysis?.bestStrike?.final_score >= 85) {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('🎯 Nuovo Segnale Wheel Strategy!', {
        body: `Strike ${analysis.bestStrike.strike} - Score ${analysis.bestStrike.final_score}`,
        icon: '/logo.png'
      });
    }
  }
}, [analysis]);
```

### 5.2 WebSocket per Real-Time Updates

```typescript
import { useEffect } from 'react';
import io from 'socket.io-client';

export function useRealtimeUpdates() {
  useEffect(() => {
    const socket = io(process.env.NEXT_PUBLIC_API_URL!);

    socket.on('connect', () => {
      console.log('Connected to WebSocket');
      socket.emit('subscribe_updates');
    });

    socket.on('analysis_update', (data) => {
      // Aggiorna UI con nuovi dati
      setAnalysis(data);
    });

    return () => socket.disconnect();
  }, []);
}
```

### 5.3 Grafici Interattivi con Recharts

Installa:
```bash
npm install recharts
```

Crea componente grafico:
```typescript
import { LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';

export function PriceChart({ data }: { data: any[] }) {
  return (
    <LineChart width={600} height={300} data={data}>
      <XAxis dataKey="timestamp" />
      <YAxis />
      <Tooltip />
      <Line type="monotone" dataKey="close" stroke="#8884d8" />
    </LineChart>
  );
}
```

---

## 🧪 STEP 6: Testing

### 6.1 Test Locale

```bash
# Terminal 1: Backend
cd backend
python api_server.py

# Terminal 2: Frontend (Lovable)
npm run dev
```

Verifica:
- ✅ API risponde su http://localhost:5000/api/health
- ✅ Frontend carica i dati
- ✅ Widget funziona
- ✅ Dashboard completa carica

### 6.2 Test Produzione

```bash
# Test API
curl https://your-api.railway.app/api/health

# Test CORS
curl -H "Origin: https://finanzacreativa.live" \
     -H "Access-Control-Request-Method: GET" \
     -X OPTIONS https://your-api.railway.app/api/analysis
```

---

## 🚀 STEP 7: Deploy Frontend su Lovable

1. **Commit modifiche** in Lovable editor
2. **Preview** per verificare tutto funzioni
3. **Deploy** quando pronto
4. Verifica URL finale: `https://finanzacreativa.live/wheel-strategy`

---

## 📊 STEP 8: Monitoraggio & Analytics

### 8.1 Aggiungi Logging

Nel tuo componente:
```typescript
useEffect(() => {
  // Track page view
  window.gtag?.('event', 'page_view', {
    page_title: 'Wheel Strategy',
    page_path: '/wheel-strategy'
  });
}, []);

const trackSignalView = (score: number) => {
  window.gtag?.('event', 'signal_view', {
    event_category: 'Trading',
    event_label: 'Wheel Strategy',
    value: score
  });
};
```

### 8.2 Error Tracking (Sentry)

```bash
npm install @sentry/react
```

```typescript
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "your-sentry-dsn",
  integrations: [new Sentry.BrowserTracing()],
  tracesSampleRate: 1.0,
});
```

---

## 🎯 STEP 9: Ottimizzazioni Performance

### 9.1 Cache API Responses

```typescript
// Usa React Query per caching
import { useQuery } from '@tanstack/react-query';

export function useWheelStrategyQuery() {
  return useQuery({
    queryKey: ['wheelStrategy'],
    queryFn: fetchAnalysis,
    staleTime: 5 * 60 * 1000, // 5 minuti
    cacheTime: 10 * 60 * 1000, // 10 minuti
  });
}
```

### 9.2 Lazy Loading

```typescript
import { lazy, Suspense } from 'react';

const WheelStrategyDashboard = lazy(() => 
  import('@/components/wheel-strategy/WheelStrategyDashboard')
);

export default function Page() {
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <WheelStrategyDashboard />
    </Suspense>
  );
}
```

---

## 🔒 STEP 10: Sicurezza

### 10.1 Rate Limiting sul Backend

```python
from flask_limiter import Limiter

limiter = Limiter(
    app,
    key_func=lambda: request.headers.get('X-Forwarded-For', request.remote_addr)
)

@app.route('/api/analysis')
@limiter.limit("10 per minute")
def get_analysis():
    # ...
```

### 10.2 API Key per Protezione (opzionale)

```python
from functools import wraps

def require_api_key(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        if api_key != os.getenv('API_KEY'):
            return jsonify({'error': 'Invalid API key'}), 401
        return f(*args, **kwargs)
    return decorated

@app.route('/api/analysis')
@require_api_key
def get_analysis():
    # ...
```

Nel frontend:
```typescript
const response = await fetch(`${API_URL}/api/analysis`, {
  headers: {
    'X-API-Key': process.env.NEXT_PUBLIC_API_KEY!
  }
});
```

---

## 📝 Checklist Finale

Usa questa checklist prima del go-live:

- [ ] Backend API deployato e funzionante
- [ ] Variabili ambiente configurate
- [ ] CORS configurato correttamente
- [ ] Componenti React integrati in Lovable
- [ ] Stili adattati al tema di finanzacreativa.live
- [ ] Test completo locale e produzione
- [ ] Notifiche funzionanti (opzionale)
- [ ] WebSocket configurato (opzionale)
- [ ] Logging e analytics attivi
- [ ] Rate limiting abilitato
- [ ] SSL/HTTPS attivo
- [ ] Documentazione aggiornata

---

## 🆘 Troubleshooting Comune

### "CORS Error"
```python
# In api_server.py
CORS(app, origins=[
    'https://finanzacreativa.live',
    'https://www.finanzacreativa.live',
    'http://localhost:3000'
])
```

### "Cannot fetch data"
- Verifica URL API in `.env`
- Check network tab nel browser
- Verifica API sia online: `curl API_URL/api/health`

### "Module not found"
```bash
# Reinstalla dipendenze
npm install
```

### "TA-Lib installation failed"
Usa il fallback manuale (già implementato nel codice)

---

## 🎉 Conclusione

Ora hai **Wheel Strategy** completamente integrato in **finanzacreativa.live**!

**Prossimi step suggeriti:**
1. Raccogli feedback utenti
2. Ottimizza UX basato su analytics
3. Aggiungi più asset (ETH, SOL)
4. Implementa backtesting UI
5. Crea sistema notifiche personalizzate

**Supporto:**
- Email: [tuo-supporto]
- Telegram: [tuo-canale]
- Documentazione: https://docs.finanzacreativa.live

---

Buon trading! 🚀
