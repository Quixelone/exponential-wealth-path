# 🚀 GUIDA RAPIDA - Setup in 5 Minuti

## Step 1: Installa Dipendenze (2 min)

```bash
# Crea ambiente virtuale
python -m venv venv
source venv/bin/activate  # Linux/Mac
# oppure: venv\Scripts\activate  # Windows

# Installa pacchetti
pip install -r requirements.txt
```

**Nota su TA-Lib**: Se l'installazione fallisce:
- Ubuntu/Debian: `sudo apt-get install ta-lib && pip install TA-Lib`
- Mac: `brew install ta-lib && pip install TA-Lib`
- Windows: Scarica wheel da https://www.lfd.uci.edu/~gohlke/pythonlibs/#ta-lib

## Step 2: Crea Bot Telegram (2 min)

1. Apri Telegram e cerca `@BotFather`
2. Invia `/newbot`
3. Scegli un nome (es. "My Wheel Strategy Bot")
4. Scegli uno username (es. "mywheelbot")
5. **Copia il token** fornito (formato: 123456789:ABCdefGHI...)

6. Trova il tuo Chat ID:
   - Cerca `@userinfobot`
   - Invia `/start`
   - **Copia l'ID** fornito (numero lungo)

7. Invia `/start` al tuo nuovo bot per attivarlo

## Step 3: Configura API Keys (1 min)

Apri `config.py` e modifica queste righe:

```python
# Inserisci le tue chiavi
TELEGRAM_BOT_TOKEN = "123456789:ABCdefGHI..."  # Il token di @BotFather
TELEGRAM_CHAT_ID = "123456789"                 # Il tuo Chat ID

# Binance API (opzionale per dati futures)
BINANCE_API_KEY = "optional_key"
BINANCE_API_SECRET = "optional_secret"
```

**IMPORTANTE**: 
- Le API Binance sono OPZIONALI (il bot funziona senza)
- Se le usi, crea keys con SOLO permessi READ (no trading!)
- NON committare config.py su GitHub

## Step 4: Test Rapido (30 sec)

```bash
# Test connessioni
python quick_test.py
```

Dovresti vedere:
- ✓ Tutti i moduli importati
- ✓ Prezzo BTC corrente
- ✓ Dati recuperati
- ✓ Bot Telegram connesso

## Step 5: Prima Analisi! (30 sec)

```bash
# Analisi singola
python main.py

# Con export JSON
python main.py --export
```

Riceverai un messaggio Telegram con:
- 💰 Prezzo corrente BTC
- 🎯 Strike consigliato
- 📊 Condizioni mercato
- 💡 Raccomandazione

## 🎯 Parametri da Personalizzare

### Per strategie più aggressive:
```python
MIN_DISTANCE_FROM_PRICE = 0.03  # 3% sotto prezzo (più rischio)
TARGET_DELTA_MIN = 0.35         # Delta più alto (più premium)
MIN_SCORE_FOR_ALERT = 70        # Soglia alert più bassa
```

### Per strategie più conservative:
```python
MIN_DISTANCE_FROM_PRICE = 0.10  # 10% sotto prezzo (meno rischio)
TARGET_DELTA_MIN = 0.20         # Delta più basso (meno premium)
MIN_SCORE_FOR_ALERT = 80        # Soglia alert più alta
```

### Per più notifiche:
```python
ALERT_COOLDOWN_HOURS = 2        # Alert ogni 2 ore
MIN_SCORE_FOR_ALERT = 65        # Soglia più bassa
```

### Per meno notifiche:
```python
ALERT_COOLDOWN_HOURS = 12       # Alert ogni 12 ore
MIN_SCORE_FOR_ALERT = 85        # Solo opportunità eccellenti
```

## 📊 Comandi Utili

```bash
# Analisi singola
python main.py

# Modalità continua (ogni ora)
python main.py --mode continuous

# Modalità continua (ogni 30 min)
python main.py --mode continuous --interval 30

# Test connessioni
python main.py --mode test

# Esporta risultati in JSON
python main.py --export

# Senza alert Telegram
python main.py --no-alert
```

## 🔧 Troubleshooting Rapido

### "ModuleNotFoundError"
```bash
pip install -r requirements.txt
```

### "Telegram connection failed"
- Verifica token e chat ID in config.py
- Invia /start al bot su Telegram
- Controlla che il token sia completo (incluso ":")

### "Binance API error" (se usi API)
- Le API Binance sono opzionali
- Verifica key e secret
- Usa solo permessi READ

### "TA-Lib error"
```bash
# Ubuntu/Debian
sudo apt-get install ta-lib
pip install TA-Lib

# Mac
brew install ta-lib
pip install TA-Lib
```

## 💡 Best Practices

1. **Inizia con analisi singole** (`python main.py`)
2. **Studia i report** per capire il sistema
3. **Personalizza i parametri** in config.py
4. **Attiva modalità continua** quando sei pronto
5. **Monitora i log** in wheel_strategy.log

## 🎓 Prossimi Passi

1. ✅ Fai girare il bot per 1-2 giorni
2. ✅ Analizza gli strike suggeriti
3. ✅ Confronta con il mercato reale
4. ✅ Ottimizza i parametri per il tuo stile
5. ✅ Usa i report per decisioni informate

## ⚠️ IMPORTANTE

- Questo è uno strumento di ANALISI, non esegue trade
- TESTA sempre in paper trading prima di usare capitale reale
- Le stime di premium sono APPROSSIMATIVE senza dati opzioni reali
- Per opzioni reali su BTC, usa Deribit (non Binance)
- Consulta sempre un professionista prima di investire

## 📞 Supporto

Problemi? Controlla:
1. README.md completo
2. Log file: wheel_strategy.log
3. Output di: python quick_test.py

---

**Buon trading! 🎯**
