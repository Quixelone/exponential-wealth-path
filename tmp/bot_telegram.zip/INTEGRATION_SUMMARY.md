# 🎯 WHEEL STRATEGY BOT - INTEGRAZIONE FINANZACREATIVA.LIVE

## 📦 Package Completo Creato

Hai ricevuto un sistema completo e production-ready per integrare l'algoritmo Wheel Strategy nella tua piattaforma finanzacreativa.live.

---

## 📂 Struttura File

### 🐍 Backend Python (Algoritmo Core)

**File Principali:**
- `main.py` - Applicazione standalone
- `api_server.py` - **API REST Flask per integrazione web**
- `config.py` - Configurazione centralizzata

**Moduli Analisi:**
- `binance_data.py` - Interfaccia Binance API
- `technical_analyzer.py` - RSI, Bollinger, TWAP, Trend
- `onchain_analyzer.py` - Funding Rate, L/S Ratio, Fear & Greed
- `strike_optimizer.py` - Algoritmo scoring strike price
- `telegram_notifier.py` - Sistema notifiche Telegram

**Utilities:**
- `quick_test.py` - Test rapido funzionalità
- `requirements.txt` - Dipendenze Python

---

### ⚛️ Frontend React (Lovable)

**Componenti:**
- `WheelStrategyDashboard.tsx` - **Dashboard completo full-page**
- `WheelStrategyWidget.tsx` - **Widget compatto per sidebar**
- `useWheelStrategy.ts` - **Custom Hook per API calls**

**Features Componenti:**
- ✅ Design responsive
- ✅ Real-time updates
- ✅ Score visualization
- ✅ Top 5 strikes ranking
- ✅ Technical indicators display
- ✅ Sentiment analysis
- ✅ Auto-refresh configurabile

---

### 🐳 Deployment

**Docker:**
- `Dockerfile` - Container API
- `docker-compose.yml` - Orchestrazione completa
- `nginx.conf` - Reverse proxy configuration

**Scripts:**
- `deploy.sh` - Deploy automatico (Railway/Render/Docker/VPS)

---

### 📚 Documentazione

1. **README.md** - Documentazione generale progetto
2. **QUICK_START.md** - Setup rapido 5 minuti
3. **MATH_GUIDE.md** - Matematica e algoritmi dettagliati
4. **LOVABLE_INTEGRATION.md** - **Guida completa integrazione**

---

## 🚀 Quick Start per finanzacreativa.live

### Step 1: Deploy Backend (5 min)

```bash
# Opzione A: Docker (più semplice)
docker-compose up -d

# Opzione B: Railway (consigliato per produzione)
./deploy.sh
# Scegli opzione 2

# Opzione C: Render
# Segui istruzioni in LOVABLE_INTEGRATION.md
```

### Step 2: Integra Frontend in Lovable (10 min)

1. **Copia file React** nel tuo progetto Lovable:
   ```
   src/components/wheel-strategy/
   ├── WheelStrategyDashboard.tsx
   └── WheelStrategyWidget.tsx
   
   src/hooks/
   └── useWheelStrategy.ts
   ```

2. **Configura ambiente** in Lovable:
   ```bash
   # .env
   NEXT_PUBLIC_API_URL=https://your-api-url.com
   ```

3. **Crea pagina**:
   ```typescript
   // src/pages/wheel-strategy.tsx
   import { WheelStrategyDashboard } from '@/components/wheel-strategy';
   
   export default function Page() {
     return <WheelStrategyDashboard />;
   }
   ```

4. **Aggiungi widget alla dashboard**:
   ```typescript
   import { WheelStrategyWidget } from '@/components/wheel-strategy';
   
   <WheelStrategyWidget compact={true} />
   ```

### Step 3: Test & Deploy (5 min)

```bash
# Test API
curl https://your-api-url.com/api/health

# Test dal browser
https://finanzacreativa.live/wheel-strategy
```

---

## 🎯 Cosa Fa il Sistema

### Backend API (Flask)

**Endpoints Disponibili:**

```
GET  /api/health                    - Health check
GET  /api/current-price             - Prezzo BTC real-time
GET  /api/analysis                  - Analisi completa + strike ottimale
GET  /api/strikes?count=5           - Top N strike prices
GET  /api/technical-indicators      - Solo indicatori tecnici
GET  /api/sentiment                 - Solo sentiment & on-chain
GET  /api/market-data?interval=1h   - Dati storici OHLCV
GET  /api/config                    - Configurazione corrente
POST /api/config                    - Aggiorna configurazione
POST /api/backtest                  - Run backtest (coming soon)
```

**WebSocket Support:**
```javascript
const socket = io('wss://your-api-url.com');
socket.on('analysis_update', (data) => {
  // Real-time updates ogni 15 minuti
});
```

### Frontend Components

**WheelStrategyDashboard** - Dashboard Completo
- Prezzo corrente BTC
- Strike price consigliato con score
- Condizioni mercato (trend, volatilità, scores)
- Indicatori tecnici (RSI, Bollinger, TWAP)
- Sentiment analysis
- Top 5 strikes ranking
- Raccomandazione complessiva
- Auto-refresh configurabile

**WheelStrategyWidget** - Widget Compatto
- Versione minimale per sidebar
- Score strike principale
- Metriche essenziali
- Perfetto per dashboard overview

**useWheelStrategy Hook** - API Management
```typescript
const { 
  analysis, 
  loading, 
  refresh,
  fetchStrikes,
  updateConfig 
} = useWheelStrategy();
```

---

## 🔧 Configurazione Parametri

### Aggressività Strategia

**Conservative (Basso Rischio):**
```python
MIN_DISTANCE_FROM_PRICE = 0.10  # 10% sotto
TARGET_DELTA_MIN = 0.20         # 20% prob ITM
MIN_SCORE_FOR_ALERT = 80        # Solo opportunità ottime
```

**Moderate (Bilanciato):**
```python
MIN_DISTANCE_FROM_PRICE = 0.05  # 5% sotto
TARGET_DELTA_MIN = 0.30         # 30% prob ITM
MIN_SCORE_FOR_ALERT = 75        # Buone opportunità
```

**Aggressive (Alto Rendimento):**
```python
MIN_DISTANCE_FROM_PRICE = 0.03  # 3% sotto
TARGET_DELTA_MIN = 0.35         # 35% prob ITM
MIN_SCORE_FOR_ALERT = 65        # Più segnali
```

### Via API (Runtime):

```javascript
await fetch('/api/config', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    min_distance_from_price: 0.07,
    target_delta_min: 0.28,
    min_score_for_alert: 78
  })
});
```

---

## 📊 Scoring System Spiegato

### Score Finale = 100 punti

**Technical Score (25%):**
- RSI: Oversold favorisce score alto
- Bollinger: Vicino lower band = score alto
- TWAP: Sotto media = score alto
- Trend: Uptrend = score alto
- Support: Vicino supporto = score alto

**Liquidity Score (20%):**
- Vicinanza a zone alta liquidità
- Open Interest positivo

**Sentiment Score (20%):**
- Funding Rate negativo = buono per PUT
- Fear dominante = buono per PUT
- L/S Ratio bilanciato = buono

**Risk/Reward Score (20%):**
- Premium > 2% = score alto
- Rapporto rischio/rendimento favorevole

**Probability Score (15%):**
- Delta 0.25-0.35 = score massimo
- Probabilità ITM nel range target

### Interpretazione:

- **85-100**: 🟢🟢🟢 Opportunità eccellente
- **75-84**: 🟢🟢 Buona opportunità
- **65-74**: 🟡 Accettabile
- **50-64**: ⚠️ Debole
- **<50**: 🔴 Evitare

---

## 💡 Use Cases per finanzacreativa.live

### 1. Dashboard Principale
```typescript
<div className="grid grid-cols-3 gap-4">
  <WheelStrategyWidget compact />
  <YourOtherWidget />
  <YourOtherWidget />
</div>
```

### 2. Pagina Dedicata Trading
```typescript
<WheelStrategyDashboard />
```

### 3. Notifiche Push
```typescript
useEffect(() => {
  if (analysis?.bestStrike?.final_score >= 85) {
    showNotification('Nuovo segnale Wheel Strategy!');
  }
}, [analysis]);
```

### 4. Custom Integration
```typescript
const { fetchStrikes } = useWheelStrategy();

const strikes = await fetchStrikes(10);
// Usa i dati come vuoi
```

---

## 🔐 Sicurezza

**API Keys:**
- Binance keys OPZIONALI (funziona senza)
- Se usi keys, SOLO permessi READ
- Mai committare .env su GitHub

**CORS:**
- Configurato per finanzacreativa.live
- Rate limiting abilitato (10 req/min)

**HTTPS:**
- Obbligatorio in produzione
- Let's Encrypt gratuito

---

## 📈 Performance

**Caching:**
- API cache: 5 minuti
- Riduce chiamate a Binance
- WebSocket per real-time

**Ottimizzazioni:**
- Lazy loading componenti
- React Query per caching frontend
- Compressione Gzip

---

## 🆘 Support & Troubleshooting

### Issue Comuni:

1. **"CORS Error"**
   - Verifica ALLOWED_ORIGINS in .env
   - Check headers in nginx.conf

2. **"Cannot fetch data"**
   - Verifica API_URL in frontend .env
   - Test: `curl API_URL/api/health`

3. **"TA-Lib error"**
   - Usa Docker (include TA-Lib)
   - O segui install manual in README

### Logs:

```bash
# Docker
docker-compose logs -f api

# VPS
sudo journalctl -u wheel-api -f

# File
tail -f wheel_strategy.log
```

---

## 🎯 Roadmap Suggerita

**Fase 1 (Immediate):**
- ✅ Deploy backend
- ✅ Integra dashboard
- ✅ Test con utenti beta

**Fase 2 (1-2 settimane):**
- [ ] Aggiungi ETH, SOL
- [ ] Implementa backtesting UI
- [ ] Sistema notifiche personalizzate

**Fase 3 (1 mese):**
- [ ] Machine Learning predictions
- [ ] Social sentiment da Twitter
- [ ] Mobile app companion

**Fase 4 (2+ mesi):**
- [ ] Trading automatico (con cautela!)
- [ ] Portfolio management
- [ ] Community signals sharing

---

## 💼 Monetizzazione per finanzacreativa.live

**Ideas:**

1. **Freemium Model:**
   - Free: 1 analisi/ora
   - Premium: Real-time updates + notifiche

2. **Subscription Tiers:**
   - Basic: €9.99/mese - Dashboard base
   - Pro: €29.99/mese - Multi-asset + backtest
   - Elite: €99.99/mese - Signals + API access

3. **B2B:**
   - White-label per altri trader
   - API access per istituzioni

---

## 📞 Conclusione

Hai ora tutto il necessario per:

✅ **Backend completo** con API REST professionale  
✅ **Frontend React** ottimizzato per Lovable  
✅ **Deployment automatizzato** su Railway/Render/Docker  
✅ **Documentazione estesa** per ogni aspetto  
✅ **Sistema production-ready** scalabile  

**Prossimo Passo:**
1. Leggi `LOVABLE_INTEGRATION.md`
2. Esegui `./deploy.sh`
3. Copia componenti React in Lovable
4. Testa e vai live!

---

**Buon trading e buon business con finanzacreativa.live! 🚀**

Per domande o supporto, contattami!
