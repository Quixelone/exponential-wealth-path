# 📐 GUIDA MATEMATICA AVANZATA - Wheel Strategy Algorithm

## Indice
1. Sistema di Scoring
2. Calcolo Delta e Probabilità ITM
3. Stima Premium (Black-Scholes Semplificato)
4. Analisi Tecnica Matematica
5. Sentiment Composito
6. Ottimizzazione Strike Price

---

## 1. Sistema di Scoring

### Formula Score Finale
```
Score_finale = Σ(Componente_i × Peso_i)

dove:
- Technical_Score × 0.25
- Liquidity_Score × 0.20  
- Sentiment_Score × 0.20
- Risk_Reward_Score × 0.20
- Probability_Score × 0.15
```

### 1.1 Technical Score (25%)

Il technical score è composto da 5 sub-componenti:

#### A. RSI Score (20 punti)
```python
if RSI < 30:        score = 20  # Oversold ottimale
elif RSI < 40:      score = 15
elif RSI < 50:      score = 10
elif RSI < 70:      score = 5
else:               score = 0   # Overbought rischioso
```

**Logica**: RSI oversold indica che il prezzo potrebbe rimbalzare, ideale per vendere PUT.

#### B. Bollinger Bands Score (20 punti)
```python
BB_position = (Prezzo - Lower_Band) / (Upper_Band - Lower_Band)

if BB_position < 0.2:     score = 20  # Vicino a lower band
elif BB_position < 0.4:   score = 15
elif BB_position < 0.6:   score = 10
elif BB_position < 0.8:   score = 5
else:                     score = 0   # Vicino a upper band
```

**Logica**: Prezzo vicino alla banda inferiore suggerisce possibile ritorno alla media.

#### C. TWAP Score (15 punti)
```python
TWAP_diff = (Prezzo_corrente - TWAP) / TWAP

if TWAP_diff < -3%:       score = 15  # Sotto TWAP
elif TWAP_diff < 0:       score = 10
elif TWAP_diff < 2%:      score = 5
else:                     score = 0
```

**Logica**: Prezzo sotto TWAP indica sottovalutazione temporanea.

#### D. Trend Score (25 punti)
```python
Trend_score = (trend_angle + MA_trend × 100 + HH_LL_score × 10) / 3

if UPTREND:     score = 25
elif SIDEWAYS:  score = 15
else:           score = 5   # DOWNTREND
```

**Componenti**:
- `trend_angle`: Pendenza regressione lineare
- `MA_trend`: (SMA_20 - SMA_50) / SMA_50
- `HH_LL_score`: (Higher_Highs - Lower_Lows) / 10

#### E. Support/Resistance Score (20 punti)
```python
distance_from_support = (Prezzo - Nearest_Support) / Prezzo

if distance < 2%:         score = 20
elif distance < 5%:       score = 15
elif distance < 10%:      score = 10
else:                     score = 5
```

---

## 2. Calcolo Delta e Probabilità ITM

### 2.1 Delta di un PUT (Black-Scholes)

```python
d1 = [ln(S/K) + (r + σ²/2) × T] / (σ × √T)
Delta_PUT = Φ(d1) - 1

dove:
- S = Prezzo spot corrente
- K = Strike price
- r = Risk-free rate (≈ 0 per crypto)
- σ = Volatilità implicita
- T = Time to expiration (anni)
- Φ = Funzione di distribuzione normale cumulativa
```

### 2.2 Probabilità ITM
```python
P(ITM) = |Delta_PUT|

Esempio:
Delta = -0.30 → 30% probabilità che PUT finisca ITM
Delta = -0.50 → 50% probabilità (At-The-Money)
```

### 2.3 Target Range Ottimale
```python
TARGET_DELTA_MIN = 0.25  # 25% prob ITM
TARGET_DELTA_MAX = 0.35  # 35% prob ITM

Probability_Score:
if 0.25 ≤ |Delta| ≤ 0.35:  score = 100  # Target range
elif 0.20 ≤ |Delta| ≤ 0.40: score = 80
elif 0.15 ≤ |Delta| ≤ 0.45: score = 60
else:                        score = 40
```

**Razionale**: Delta 0.25-0.35 offre equilibrio tra premium raccolto e rischio di assegnazione.

---

## 3. Stima Premium (Black-Scholes Semplificato)

### 3.1 Formula Premium PUT
```python
Premium_PUT = Intrinsic_Value + Time_Value

Intrinsic_Value = max(0, K - S)

Time_Value = S × σ × √T × (1 - moneyness)

dove:
moneyness = K / S
```

### 3.2 Risk/Reward Score
```python
Premium_percent = (Premium / Strike) × 100

if Premium_percent > 3%:    score = 100  # Eccellente
elif Premium_percent > 2%:  score = 80
elif Premium_percent > 1%:  score = 60
else:                       score = 40
```

### 3.3 Rendimento Annualizzato
```python
ROI_annualized = (Premium / Strike) × (365 / DTE)

Esempio:
Strike: $90,000
Premium: $1,800 (2%)
DTE: 14 giorni

ROI = (1,800 / 90,000) × (365 / 14) = 52.1% annualizzato
```

---

## 4. Analisi Tecnica Matematica

### 4.1 RSI (Relative Strength Index)
```python
RS = Avg_Gain(n) / Avg_Loss(n)
RSI = 100 - [100 / (1 + RS)]

dove n = periodo (default 14)
```

### 4.2 Bollinger Bands
```python
Middle_Band = SMA(n)
Upper_Band = Middle_Band + (k × σ)
Lower_Band = Middle_Band - (k × σ)

dove:
- n = periodo (default 20)
- k = numero deviazioni standard (default 2)
- σ = deviazione standard dei prezzi
```

### 4.3 TWAP (Time-Weighted Average Price)
```python
TWAP = Σ(P_i × w_i) / Σw_i

dove:
- P_i = prezzo al tempo i
- w_i = peso temporale (linearmente crescente)

Implementazione:
weights = linspace(1, 2, period)
TWAP = average(prices[-period:], weights=weights)
```

### 4.4 Volatilità Storica Annualizzata
```python
returns = ln(P_t / P_t-1)
σ_daily = std(returns)
σ_annual = σ_daily × √365

Percentile:
rank = len([σ < σ_current]) / len(σ_history) × 100
```

### 4.5 Trend Detection (Regressione Lineare)
```python
slope, intercept = polyfit(x, prices, deg=1)
trend_angle = arctan(slope / mean(prices)) × 100

Interpretazione:
trend_angle > 2:   UPTREND
-2 ≤ trend_angle ≤ 2: SIDEWAYS
trend_angle < -2:  DOWNTREND
```

---

## 5. Sentiment Composito

### 5.1 Formula Sentiment Score
```python
Sentiment = Σ(Component_i × Weight_i)

Componenti (weights):
- Funding_Rate (0.25)
- Long_Short_Ratio (0.25)  
- Fear_Greed_Index (0.30)
- Open_Interest (0.20)
```

### 5.2 Normalizzazione Componenti

#### Funding Rate
```python
# Range tipico: -0.001 a +0.001
normalized = (funding_rate / 0.001) × 50 + 50
score = clip(normalized, 0, 100)

Interpretazione:
> 0.0005:  Very Bullish (score > 75)
> 0.0001:  Bullish (score > 55)
< -0.0005: Very Bearish (score < 25)
< -0.0001: Bearish (score < 45)
```

#### Long/Short Ratio
```python
# Range tipico: 0.5 a 2.0
normalized = (ratio - 0.5) / 1.5 × 100
score = clip(normalized, 0, 100)

Interpretazione:
> 1.2: Bullish dominante
< 0.8: Bearish dominante
```

#### Fear & Greed Index
```python
# Range: 0-100
# Invertiamo: Fear è buono per PUT
if value ≤ 50:
    score = 100 - value  # Fear → High score
else:
    score = 100 - value  # Greed → Low score
```

### 5.3 Interpretazione Finale
```python
if composite_score < 30:   "VERY_BEARISH" → EXCELLENT for PUT
elif composite_score < 45: "BEARISH" → GOOD for PUT
elif composite_score < 55: "NEUTRAL" → MODERATE for PUT
elif composite_score < 70: "BULLISH" → CAUTION with PUT
else:                      "VERY_BULLISH" → AVOID PUT
```

---

## 6. Ottimizzazione Strike Price

### 6.1 Generazione Candidati
```python
min_strike = S × (1 - MAX_DISTANCE)  # Es. S × 0.85
max_strike = S × (1 - MIN_DISTANCE)  # Es. S × 0.95

step = S × 0.01  # 1% incrementi
candidates = arange(min_strike, max_strike, step)

# Arrotondamento
if S > 10000: candidates = round(candidates / 100) × 100
```

### 6.2 Scoring Aggregato per Strike
```python
for each candidate_strike:
    
    # 1. Calculate all component scores
    tech_score = calculate_technical_score()
    liq_score = calculate_liquidity_score()
    sent_score = sentiment_composite_score
    rr_score = calculate_risk_reward_score()
    prob_score = calculate_probability_score()
    
    # 2. Weighted average
    final_score = (
        tech_score × 0.25 +
        liq_score × 0.20 +
        sent_score × 0.20 +
        rr_score × 0.20 +
        prob_score × 0.15
    )
    
    # 3. Filter by minimum threshold
    if final_score >= MIN_SCORE_FOR_ALERT:
        qualified_strikes.append(strike_data)

# 4. Sort and return top N
return sorted(qualified_strikes, key=score, reverse=True)[:N]
```

### 6.3 Break-Even Analysis
```python
Break_Even = Strike - Premium_Received

Esempio:
Strike: $90,000
Premium: $1,800
Break-Even: $88,200

Max_Loss = Strike - Break_Even = $1,800 (il premium)
Max_Profit = Premium = $1,800
Win_Rate_Needed = 1 / (1 + Max_Profit/Max_Loss) = 50%
```

### 6.4 Expected Value
```python
P_OTM = 1 - |Delta|
P_ITM = |Delta|

Expected_Value = (Premium × P_OTM) - (Avg_Loss_if_ITM × P_ITM)

Dove Avg_Loss_if_ITM dipende da:
- Stop loss impostato
- Gestione del roll
- Volatilità del sottostante
```

---

## 7. Esempi Pratici

### Esempio 1: Strike Perfetto

```
Condizioni:
- BTC @ $95,000
- RSI: 32 (oversold)
- Prezzo @ Lower Bollinger Band
- Trend: UPTREND
- Sentiment: BEARISH (Fear & Greed: 28)
- Funding Rate: -0.0003 (bearish)

Strike Proposto: $90,000
- Distanza: 5.26%
- Delta: -0.28 (28% prob ITM)
- Premium: $1,900 (2.1%)
- Score: 89/100

Component Breakdown:
- Technical: 85/100 (RSI oversold, BB lower)
- Liquidity: 90/100 (vicino a zona liquida)
- Sentiment: 72/100 (fear dominante)
- Risk/Reward: 100/100 (premium 2.1%)
- Probability: 95/100 (delta perfetto 0.28)

Raccomandazione: STRONG BUY
```

### Esempio 2: Strike Mediocre

```
Condizioni:
- BTC @ $95,000
- RSI: 65 (neutrale alto)
- Prezzo @ Middle Bollinger Band
- Trend: SIDEWAYS
- Sentiment: NEUTRAL
- Funding Rate: +0.0001

Strike Proposto: $88,000
- Distanza: 7.37%
- Delta: -0.15 (15% prob ITM)
- Premium: $950 (1.08%)
- Score: 58/100

Component Breakdown:
- Technical: 45/100 (nessun segnale forte)
- Liquidity: 60/100 (liquidità media)
- Sentiment: 55/100 (neutrale)
- Risk/Reward: 55/100 (premium basso)
- Probability: 45/100 (delta troppo basso)

Raccomandazione: WEAK - Consider alternatives
```

---

## 8. Metriche di Performance

### Sharpe Ratio (per backtest)
```python
Sharpe = (Mean_Return - Risk_Free_Rate) / Std_Return

Target: Sharpe > 1.5 per strategie opzioni
```

### Win Rate
```python
Win_Rate = Trades_Profitable / Total_Trades

Target Wheel Strategy: 65-75%
```

### Profit Factor
```python
Profit_Factor = Gross_Profit / Gross_Loss

Target: > 1.5
```

### Maximum Drawdown
```python
MDD = (Peak_Value - Trough_Value) / Peak_Value

Limite consigliato: < 20%
```

---

## 9. Risk Management Matematico

### Position Sizing (Kelly Criterion)
```python
f* = (p × b - q) / b

dove:
- p = probabilità di vincita
- q = probabilità di perdita (1 - p)
- b = odds (profit/loss ratio)

Wheel Strategy:
f* = (0.70 × 1 - 0.30) / 1 = 0.40

Raccomandazione: Usa 1/4 del Kelly = 10% del capitale
```

### Value at Risk (VaR)
```python
VaR_95% = μ - 1.645 × σ

Esempio:
μ = +2% return atteso
σ = 5% volatilità
VaR_95% = 2% - 1.645 × 5% = -6.22%

Interpretazione: 95% di confidenza di non perdere più del 6.22%
```

---

## 10. Considerazioni Finali

### Limiti del Modello

1. **Premium Approssimativo**: Senza IV reale da opzioni, usiamo volatilità storica
2. **Liquidità Simulata**: Heatmap basata su pattern, non dati reali
3. **Slippage**: Non considerato nel calcolo
4. **Commission**: Non incluse nelle stime

### Miglioramenti Futuri

1. **Integrazione Deribit**: IV reale e catena opzioni
2. **Machine Learning**: Pattern recognition per condizioni ottimali
3. **Monte Carlo**: Simulazione migliaia di scenari
4. **Greeks Completi**: Gamma, Theta, Vega hedging

### Best Practices

1. **Usa Multiple Timeframes**: Conferma segnali su 1H, 4H, 1D
2. **Backtest**: Almeno 1 anno di dati storici
3. **Paper Trade**: 1-2 mesi prima di capitale reale
4. **Risk Management**: Mai > 5% capitale per singola posizione
5. **Emotional Control**: Segui il sistema, ignora noise

---

**Disclaimer**: Questo è un modello matematico per analisi. Non garantisce profitti. Il trading comporta rischi significativi.
