# 🎯 Wheel Strategy Bot per BTC/USDT

Bot avanzato per identificare i migliori strike price nella **Wheel Strategy** su BTC/USDT, con analisi multi-fattoriale e notifiche Telegram.

## 📋 Caratteristiche

### Analisi Tecnica
- ✅ **RSI** (Relative Strength Index)
- ✅ **Bollinger Bands**
- ✅ **TWAP** (Time-Weighted Average Price)
- ✅ **VWAP** (Volume-Weighted Average Price)
- ✅ **Trend Detection** (Uptrend/Downtrend/Sideways)
- ✅ **Volatilità Storica** e percentili
- ✅ **Support/Resistance** automatici

### Analisi On-Chain & Sentiment
- ✅ **Funding Rate** (Binance Futures)
- ✅ **Long/Short Ratio**
- ✅ **Fear & Greed Index**
- ✅ **Open Interest** e variazioni
- ✅ **Liquidation Heatmap** simulata
- ✅ **Sentiment Composito** ponderato

### Strike Price Optimization
- ✅ Calcolo **Delta** e probabilità ITM
- ✅ Stima **Premium** con Black-Scholes
- ✅ **Risk/Reward Analysis**
- ✅ **Liquidity Scoring**
- ✅ Ranking automatico top 5 strikes

### Notifiche Telegram
- ✅ Alert automatici con score sopra soglia
- ✅ Report dettagliati formattati
- ✅ Top 5 strikes in tempo reale
- ✅ Analisi completa on-demand
- ✅ Cooldown configurabile tra alert

## 🚀 Installazione

### 1. Requisiti
- Python 3.8+
- pip
- Account Binance (per dati API)
- Bot Telegram (per notifiche)

### 2. Setup Ambiente

```bash
# Clona o scarica il progetto
git clone <tuo-repo>
cd wheel-strategy-bot

# Crea ambiente virtuale (raccomandato)
python -m venv venv
source venv/bin/activate  # Linux/Mac
# oppure
venv\Scripts\activate  # Windows

# Installa dipendenze
pip install -r requirements.txt
```

### 3. Configurazione

Modifica il file `config.py` con i tuoi parametri:

```python
# API Keys
BINANCE_API_KEY = "tua_chiave_binance"
BINANCE_API_SECRET = "tuo_secret_binance"
TELEGRAM_BOT_TOKEN = "token_del_tuo_bot"
TELEGRAM_CHAT_ID = "tuo_chat_id"

# Parametri Strategy
MIN_DISTANCE_FROM_PRICE = 0.05  # 5% sotto prezzo
MAX_DISTANCE_FROM_PRICE = 0.15  # 15% sotto prezzo
TARGET_DELTA_MIN = 0.25  # Delta target minimo
TARGET_DELTA_MAX = 0.35  # Delta target massimo

# Notifiche
MIN_SCORE_FOR_ALERT = 75  # Score minimo per alert
ALERT_COOLDOWN_HOURS = 6  # Ore tra un alert e l'altro
```

### 4. Setup Bot Telegram

1. Cerca `@BotFather` su Telegram
2. Invia `/newbot` e segui le istruzioni
3. Copia il token fornito
4. Trova il tuo Chat ID:
   - Cerca `@userinfobot`
   - Invia `/start`
   - Copia l'ID fornito

## 📊 Utilizzo

### Modalità Singola (Default)
Esegue un'analisi singola e invia alert se le condizioni sono soddisfatte:

```bash
python main.py
```

### Modalità Continua
Esegue analisi a intervalli regolari:

```bash
# Ogni 60 minuti (default)
python main.py --mode continuous

# Ogni 30 minuti
python main.py --mode continuous --interval 30

# Ogni 4 ore
python main.py --mode continuous --interval 240
```

### Test Connessioni
Verifica che tutte le API siano raggiungibili:

```bash
python main.py --mode test
```

### Opzioni Aggiuntive

```bash
# Esporta report in JSON
python main.py --export

# Non inviare alert Telegram
python main.py --no-alert

# Combinazioni
python main.py --mode continuous --interval 120 --export
```

## 📈 Interpretazione dei Risultati

### Score System (0-100)

Il bot calcola uno score finale per ogni strike price basato su:

1. **Technical Score (25%)**: RSI, Bollinger, TWAP, Trend
2. **Liquidity Score (20%)**: Open Interest, Heatmap liquidazioni
3. **Sentiment Score (20%)**: Funding Rate, L/S Ratio, Fear & Greed
4. **Risk/Reward Score (20%)**: Premium vs Rischio
5. **Probability Score (15%)**: Delta e probabilità ITM

### Interpretazione Score

- **85-100**: 🟢🟢🟢 STRONG BUY - Condizioni eccellenti
- **75-84**: 🟢🟢 BUY - Buone condizioni
- **65-74**: 🟡 MODERATE - Accettabile
- **50-64**: ⚠️ WEAK - Valuta alternative
- **0-49**: 🔴 AVOID - Condizioni sfavorevoli

### Esempio Output

```
🟢🟢🟢 WHEEL STRATEGY - BTC/USDT

📅 2025-01-15 14:30:00

💰 PREZZO CORRENTE
$95,432.50

🎯 STRIKE CONSIGLIATO
$90,000.00
Distanza: 5.69%
Score: 87.3/100

💵 PREMIUM STIMATO
$1,245.00 (1.38%)
Delta: -0.32
Prob. ITM: 32.0%

📊 CONDIZIONI MERCATO
• Trend: UPTREND
• Score Tecnico: 85.2/100
• Score Sentiment: 78.5/100
• Volatilità: 45.32%

💡 RACCOMANDAZIONE
STRONG BUY - Excellent strike price
```

## 🛠️ Architettura del Sistema

```
wheel-strategy-bot/
│
├── config.py                  # Configurazione centrale
├── main.py                    # Applicazione principale
│
├── binance_data.py           # Interface Binance API
├── technical_analyzer.py     # Analisi tecnica (RSI, BB, TWAP)
├── onchain_analyzer.py       # On-chain & Sentiment
├── strike_optimizer.py       # Motore ottimizzazione strikes
├── telegram_notifier.py      # Sistema notifiche Telegram
│
├── requirements.txt          # Dipendenze Python
├── README.md                 # Documentazione
└── wheel_strategy.log        # Log file
```

## ⚙️ Parametri Configurabili

### Strike Selection
```python
MIN_DISTANCE_FROM_PRICE = 0.05    # Min distanza dal prezzo
MAX_DISTANCE_FROM_PRICE = 0.15    # Max distanza dal prezzo
TARGET_DELTA_MIN = 0.25           # Delta minimo target
TARGET_DELTA_MAX = 0.35           # Delta massimo target
PREFERRED_DTE_MIN = 7             # Giorni a scadenza min
PREFERRED_DTE_MAX = 30            # Giorni a scadenza max
```

### Technical Analysis
```python
RSI_PERIOD = 14                   # Periodo RSI
RSI_OVERSOLD = 30                 # Soglia oversold
BOLLINGER_PERIOD = 20             # Periodo Bollinger
BOLLINGER_STD = 2                 # Deviazioni standard
TREND_LOOKBACK = 50               # Candele per trend
```

### Sentiment Weights
```python
SENTIMENT_WEIGHTS = {
    'funding_rate': 0.25,
    'long_short_ratio': 0.25,
    'fear_greed_index': 0.30,
    'social_volume': 0.20
}
```

### Score Weights
```python
SCORE_WEIGHTS = {
    'technical_score': 0.25,
    'liquidity_score': 0.20,
    'sentiment_score': 0.20,
    'risk_reward_score': 0.20,
    'probability_score': 0.15
}
```

## 🔍 Indicatori Dettagliati

### RSI (Relative Strength Index)
- **Oversold (<30)**: Ottimo per vendere PUT
- **Neutral (30-70)**: Condizioni normali
- **Overbought (>70)**: Cautela con PUT

### Bollinger Bands
- **Prezzo vicino Lower Band**: Buono per PUT
- **Prezzo al centro**: Neutro
- **Prezzo vicino Upper Band**: Rischioso per PUT

### TWAP vs Prezzo
- **Prezzo sotto TWAP**: Potenziale rimbalzo
- **Prezzo sopra TWAP**: Momentum positivo

### Trend Detection
- **UPTREND**: Condizioni favorevoli per PUT
- **SIDEWAYS**: Condizioni moderate
- **DOWNTREND**: Cautela necessaria

### Sentiment Composito
- **<30**: Molto Bearish - Eccellente per PUT
- **30-45**: Bearish - Buono per PUT
- **45-55**: Neutrale - Moderato
- **55-70**: Bullish - Cautela
- **>70**: Molto Bullish - Evitare PUT

## 📱 Comandi Telegram

Il bot invia automaticamente:

1. **Alert Strike**: Quando trova un'opportunità valida
2. **Top 5 Strikes**: Classifica dei migliori strikes
3. **Analisi Dettagliata**: Report completo su richiesta
4. **Error Alerts**: Notifiche di errori critici

## 🔐 Sicurezza

- ⚠️ **NON condividere** le tue API keys
- ✅ Usa API keys con **soli permessi di lettura** (no trading)
- ✅ Mantieni il `config.py` **privato** (aggiungi a .gitignore)
- ✅ Usa environment variables per secrets in produzione

```bash
# Esempio con variabili d'ambiente
export BINANCE_API_KEY="your_key"
export TELEGRAM_BOT_TOKEN="your_token"
```

## 🐛 Troubleshooting

### "TA-Lib installation failed"
TA-Lib richiede librerie native. Su Ubuntu/Debian:
```bash
sudo apt-get install ta-lib
pip install TA-Lib
```

Su Mac con Homebrew:
```bash
brew install ta-lib
pip install TA-Lib
```

Su Windows: Scarica il wheel precompilato da [Christoph Gohlke](https://www.lfd.uci.edu/~gohlke/pythonlibs/#ta-lib)

### "Telegram connection failed"
- Verifica token bot corretto
- Verifica chat ID corretto
- Assicurati di aver inviato `/start` al bot
- Controlla firewall/proxy

### "Binance API error"
- Verifica API key e secret
- Controlla rate limits
- Verifica connessione internet

## 📊 Logging

Il bot genera log dettagliati in `wheel_strategy.log`:

```python
# Cambia livello log in config.py
LOG_LEVEL = "DEBUG"  # DEBUG, INFO, WARNING, ERROR
```

## 🔄 Aggiornamenti Futuri

### Pianificati
- [ ] Integrazione **Deribit** per dati opzioni reali
- [ ] Support per **ETH/USDT** e altri asset
- [ ] **Backtesting** engine
- [ ] Dashboard **web-based**
- [ ] Machine Learning per **pattern recognition**
- [ ] Database per **storico analisi**
- [ ] API REST per **integrazione esterna**

### In Sviluppo
- [ ] Calcolo Greeks (Gamma, Theta, Vega)
- [ ] Analisi correlazione BTC/altcoin
- [ ] Social sentiment da Twitter/Reddit
- [ ] Alert multicanale (Discord, Email)

## 📝 Note Importanti

1. **Questo bot è per ANALISI**, non esegue trade automatici
2. I premium stimati sono **approssimativi** senza dati opzioni reali
3. Per opzioni reali su BTC, usa **Deribit** (non Binance)
4. **Testa sempre** in paper trading prima di usare capitale reale
5. La Wheel Strategy richiede **capitale significativo**
6. Considera **slippage** e **commissioni** nelle decisioni

## 🤝 Contributi

Contributi benvenuti! 

## ⚖️ Disclaimer

**QUESTO SOFTWARE È FORNITO "AS IS" SENZA GARANZIE.**

- Non è consulenza finanziaria
- L'autore non è responsabile per perdite
- Il trading di opzioni comporta rischi significativi
- Investi solo capitale che puoi permetterti di perdere
- Consulta un consulente finanziario professionista

## 📄 Licenza

MIT License - Vedi LICENSE file

## 📞 Supporto

Per domande, problemi o suggerimenti:
- Apri una Issue su GitHub
- Email: [tuo-email]
- Telegram: [@tuo-username]

---

**Buon trading responsabile! 🚀**
